
public class RecordKey {
	String key;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	
	@Override
	public int hashCode() {
        int h = 0;
        if (h == 0 && key.length() > 0) {
            char val[] = key.toCharArray();
            for (int i = 0; i < key.length(); i++) {
                h = 31 * h + val[i];
            }
        }
        return h;
    }
}
