import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Set;

public class StudentRecords {

	public static void main(String args[]){
		StudentRecords r = new StudentRecords();
		StudentHash<String, Float> records = r.initializeHash();
		r.readFile(records);
		//r.hallOfFame(records, 6.0F);
		r.depAvg(records);
	}
	
	StudentHash<String, Float> initializeHash(){
		StudentHash<String, Float> record = new StudentHash();
		return record;
	}
	
	void insertStudentRec(StudentHash<String, Float> records, String studentId, float CGPA){
		records.put(studentId, CGPA);
	}
	
	private void readFile(StudentHash<String, Float> records) {
		final String FILENAME = "src/input/input.txt";
			BufferedReader br = null;
			FileReader fr = null;
			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				String sCurrentLine;
				while ((sCurrentLine = br.readLine()) != null) {
					String[] arr=sCurrentLine.split(",");
					records.put(arr[0], Float.parseFloat(arr[1]));
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (br != null)
						br.close();
					if (fr != null)
						fr.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
		

	void hallOfFame(StudentHash<String, Float> records, float CGPA){
		String type="HF";
		Set<String> keys = records.keySet();
        for(String key: keys){
            if(records.get(key) > CGPA){
            	writeToFile(key,records.get(key),type);
            }
        }
	}
	

	void newCourseList(StudentHash<String, Float> records, float CGPAFrom, float CPGATo){
		String type="CL";
		Set<String> keys = records.keySet();
        for(String key: keys){
            if((records.get(key)>CGPAFrom && records.get(key)<CPGATo) && inPastFiveYears(key)){
            	writeToFile(key, records.get(key),type);
            }
        }
	}
	
	private boolean inPastFiveYears(String key) {
		int year = Integer.parseInt(key.substring(0,4));
		int currentYear = Calendar.getInstance().get(Calendar.YEAR - 5);
		if(year>currentYear || year==currentYear){
			return true;
		}
		return false;
	}
	
	private void writeToFile(String key, Float float1, String type) {
		String filePath= "src/output/";
		String fileName = getFileNameForType(type);
		try{
			File file = new File(filePath+fileName);
			if(!file.exists()){
		    	file.createNewFile();
		    }
			FileWriter fw = new FileWriter(file,true);
	    	BufferedWriter bw = new BufferedWriter(fw);
	    	bw.write(key+ "   " +float1);
	    	bw.newLine();
	    	bw.close();
		}catch(IOException ex){
			ex.printStackTrace();
		}
	}

	private String getFileNameForType(String type) {
		if(type.equalsIgnoreCase("HF"))
			return "halloffame.txt";
		else if(type.equalsIgnoreCase("CL"))
			return "courseOffer.txt";
		else
			return "departmentAverage.txt";
	}

	void depAvg(StudentHash<String, Float> records){
		ArrayList<Float> avgList=new ArrayList<>();
		ArrayList<Float> maxList=new ArrayList<>();
		ArrayList<String> deptList=new ArrayList<>();
		ArrayList<Float> sumList=new ArrayList<>();
		ArrayList<Integer> countList=new ArrayList<>();
		
		Set<String> keys = records.keySet();
		for(String key: keys){
			String dept=key.substring(4, 7);
			if(deptList.contains(dept)){
				int index = deptList.lastIndexOf(dept);
				if(maxList.get(index)<= records.get(key)){
					maxList.add(index, records.get(key));
				}
				
				sumList.add(index, sumList.get(index)+records.get(key));
				countList.add(index, countList.get(index)+1);
				
			}else{
				deptList.add(dept);
				maxList.add(records.get(key));
				countList.add(1);
				sumList.add(records.get(key));
			}
		}
		 for(int i=0;i<deptList.size();i++){
			 avgList.add(sumList.get(i)/countList.get(i));
		 }
		
		 for(int i=0;i<deptList.size();i++){
			 writeToFile(deptList.get(i)+ "   "+ maxList.get(i), avgList.get(i), "DP");
		 }
	}
	
	void destroyHash(StudentHash<String, Float> records){
		records = null;
	}
}
