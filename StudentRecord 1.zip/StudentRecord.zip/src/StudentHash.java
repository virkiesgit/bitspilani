import java.util.Hashtable;

public class StudentHash<K,V> extends Hashtable<K,V>{
	
}
